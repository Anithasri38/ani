package com.example.shopping.WalletServiceManagemnet.Controller;
import java.util.List;

import org.json.JSONObject; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopping.WalletServiceManagemnet.Models.Ewallet;
import com.example.shopping.WalletServiceManagemnet.Models.Statement;
import com.example.shopping.WalletServiceManagemnet.Repository.StatementRepository;
import com.example.shopping.WalletServiceManagemnet.Service.EwalletService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@RestController
@RequestMapping("/ewallet")
public class WalletController {

	@Autowired
	  EwalletService ewalletService;
	
	@Autowired
	  StatementRepository stateRepository;
	
	@GetMapping("/all")
	public List<Ewallet> getWallets()
	{
		return ewalletService.getWallets();
	}
	@PostMapping("/addforProfile/{profileId}")
	public Ewallet addWalletForProfile(@PathVariable int profileId)
	{
		return ewalletService.addWalletForProfile(profileId);
	}
	@PostMapping("/addmoney/{amount}")
	public String onlinePayment(@PathVariable double amount)throws RazorpayException
	{
		double amt=amount;
		System.out.println(amt);
		RazorpayClient client=new RazorpayClient("rzp_live_nfBYZhXVvVbC3V","2T79eCFwFuR5Z0vJ6dqaG5JL");
		JSONObject options=new JSONObject();
		options.put("amount", amt);
		options.put("currency","INR");
		options.put("receipt","txn_123456");
		Order order=client.Orders.create(options);
		System.out.println(order);
		return order.toString();
	}
	@PostMapping("/addMoneyWallet/{amount}/{profileId}")
	public void addWallet(@PathVariable int profileId,@PathVariable double amount)
	{
		ewalletService.addMoney(profileId, amount);
	}
	@PostMapping("/transaction/{amount}/{profileId}")
	public void doTransaction(@PathVariable int profileId,@PathVariable double amount)
	{
		ewalletService.doTransaction(profileId, amount);
	}
	@GetMapping("/getById/{profileId}")
	public Ewallet getWalletById(@PathVariable int profileId)
	{
		return ewalletService.getWalletById(profileId);
	}
	@GetMapping("/statement/byId/{statementId}")
	public List<Statement> getStatementById(@PathVariable int statementId)
	{
		return ewalletService.getAllStatements();
	}
	@GetMapping("/statement/all")
	public List<Statement> getAllStatements()
	{
		return ewalletService.getAllStatements();
	}
	@DeleteMapping("/delete/{ewalletId}")
	public String deleteWalletByEwalletId(@PathVariable int ewalletId)
	{
		return ewalletService.deleteWalletById(ewalletId);
	}
	@DeleteMapping("/deletes/{profileId}")
	public String deleteWalletById(@PathVariable int profileId)
	{
         stateRepository.deleteById(profileId);
         return "done";
	}
	
}
