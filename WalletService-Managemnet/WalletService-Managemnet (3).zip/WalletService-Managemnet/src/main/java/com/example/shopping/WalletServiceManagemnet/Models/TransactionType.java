package com.example.shopping.WalletServiceManagemnet.Models;

public enum TransactionType {

	DEBIT,CREDIT;
}
