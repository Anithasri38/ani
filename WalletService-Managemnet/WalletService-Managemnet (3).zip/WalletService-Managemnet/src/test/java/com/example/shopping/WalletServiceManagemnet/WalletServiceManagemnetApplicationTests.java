package com.example.shopping.WalletServiceManagemnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletServiceManagemnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
