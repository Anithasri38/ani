package com.example.shopping.WalletServiceManagemnet.Models;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
//@AllArgsConstructor
@NoArgsConstructor
@Document(collection="Ewallet")
public class Ewallet {
     @Id
	private String walletId;
	private int profileId;
	private double currentBalance;
	private List<Statement> statement;
	public Ewallet(int profileId,double currentBalance,List<Statement> statements)
	{
		this.profileId=profileId;
		this.currentBalance=currentBalance;
		this.statement=statements;
	}
}
