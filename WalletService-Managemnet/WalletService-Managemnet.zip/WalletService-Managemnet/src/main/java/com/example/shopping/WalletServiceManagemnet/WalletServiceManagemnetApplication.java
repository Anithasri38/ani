package com.example.shopping.WalletServiceManagemnet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletServiceManagemnetApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletServiceManagemnetApplication.class, args);
	}

}
