package com.example.shoppingcart.ProfileServiceManagement.Exception;

public class ProfileAlreadyExistsException extends RuntimeException{

private String message;
	
	public ProfileAlreadyExistsException(String message) {
		super(message);
		this.message=message;
	}
	public ProfileAlreadyExistsException() {
		
	}
}
