package com.example.shoppingcart.ProfileServiceManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.shoppingcart.ProfileServiceManagement.Models.UserProfile;
import com.example.shoppingcart.ProfileServiceManagement.Service.ProfileService;

@RestController
public class ProfileController {

	@Autowired
	ProfileService profileService;
	public ProfileController(ProfileService profileService)
	{
		this.profileService=profileService;
	}
	public ProfileController()
	{
		
	}
	@GetMapping("/profile")
	public List<UserProfile> getAllProfiles()
	{
		return profileService.getAllProfiles();
	}
	@GetMapping("/profile/{profileId}")
	public UserProfile getProfileById(@PathVariable int profileId)
	{
		return profileService.getByProfileId(profileId);
	}
	
	@PutMapping("/profile/update")
	public UserProfile updateProfile(@RequestBody UserProfile userProfile)
	{
		return profileService.updateProfile(userProfile);
	}
	@PostMapping("/profile/add/customer")
	public UserProfile addNewCustomerProfile(@RequestBody UserProfile userProfile)
	{
		return profileService.addNewCustomerProfile(userProfile);
	}
	@PostMapping("/profile/add/merchant")
	public UserProfile addNewMerchantProfile(@RequestBody UserProfile userProfile)
	{
		 return profileService.addNewMerchantProfile(userProfile);
	}
	@PostMapping("/profile/add/deliveryAgent")
	public UserProfile addNewDeliveryAgentProfile(@RequestBody UserProfile userProfile)
	{
		  return profileService.addNewDeliveryProfile(userProfile);
	}
	@DeleteMapping("/profile/delete/{id}")
	public void deleteProfileById(@PathVariable int id)
	{
		profileService.deleteProfile(id);
	}
}
