package com.example.shoppingcart.profile.models;

public interface Role {

	static final String customer="customer";
	static final String merchant="merchant";
	static final String deliveryAgent="deliveryAgent";
}
