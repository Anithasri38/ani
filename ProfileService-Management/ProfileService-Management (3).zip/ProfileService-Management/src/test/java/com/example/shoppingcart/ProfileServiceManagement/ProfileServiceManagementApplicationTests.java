package com.example.shoppingcart.ProfileServiceManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileServiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
