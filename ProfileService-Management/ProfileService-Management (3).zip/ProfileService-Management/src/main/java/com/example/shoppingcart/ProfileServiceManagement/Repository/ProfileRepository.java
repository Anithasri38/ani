package com.example.shoppingcart.ProfileServiceManagement.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.shoppingcart.ProfileServiceManagement.Models.UserProfile;
@Repository
public interface ProfileRepository extends MongoRepository<UserProfile,Integer>{

	public UserProfile findByMobileNumber(Long phnNum);
	public UserProfile findByFullName(String fullName);
}
